# UAV multispectral imagery access

The UAV multispectral orthomosaics used in the study are large (approximately 6 GB) and are therefore not stored directly in this GitHub repository.

The author-provided public download link is:

**Quark Cloud:** https://pan.quark.cn/s/da72cf8f8f82

The archive is named `UAV-data.zip` and contains orchard orthomosaics for May, August, and September. Each month includes the four co-registered Mavic 3 Multispectral bands used in the study: Green, Red, RedEdge, and NIR.

> Note: External cloud links can expire or be changed by the hosting service. If the link is unavailable, or if additional data are needed for academic research or collaboration, please contact **Dr. Wenjie Li** at **17395844880@163.com**.

## Ground LAI measurements

The complete ground-measured LAI table is not bundled in this public repository. An anonymized example table is provided only to document the required input schema. Ground LAI measurements may be requested for academic purposes by contacting Dr. Wenjie Li at the email above.
