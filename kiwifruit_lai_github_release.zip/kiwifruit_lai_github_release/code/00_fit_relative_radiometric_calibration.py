#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Reference implementation of the pseudo-invariant-feature (PIF) relative
radiometric calibration step used before dynamic ROI extraction.

The paper models band-wise apparent reflectance as:

    reflectance = a * DN + b

For each acquisition date and spectral band, multiple candidate PIF/endmember
combinations can be evaluated. This script enumerates combinations containing at
least two PIF classes, keeps fits with positive gain (a > 0), and selects the
combination with the highest R2. It then writes a coefficient table that can be
merged into the imagery configuration consumed by scripts 01 and 02.

Input CSV columns
-----------------
Date              acquisition date, e.g. 2024-08-07
Band              Green, Red, RedEdge, or NIR
PIF               label of the pseudo-invariant feature / target type
DN                 representative mean DN value for that PIF ROI
TargetReflectance  fixed prior target reflectance (0-1)

The public repository does not bundle the original PIF ROI measurements. See the
example template in ../examples/example_pif_calibration_template.csv.
"""

from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

BANDS = ["Green", "Red", "RedEdge", "NIR"]


def fit_best_combination(group: pd.DataFrame, min_pif_types: int = 2) -> dict:
    pif_types = sorted(group["PIF"].astype(str).unique())
    candidates = []

    for r in range(min_pif_types, len(pif_types) + 1):
        for combo in itertools.combinations(pif_types, r):
            sub = group[group["PIF"].astype(str).isin(combo)].copy()
            sub = sub.dropna(subset=["DN", "TargetReflectance"])
            if len(sub) < 2 or sub["DN"].nunique() < 2:
                continue

            X = sub[["DN"]].to_numpy(dtype=float)
            y = sub["TargetReflectance"].to_numpy(dtype=float)
            model = LinearRegression().fit(X, y)
            a = float(model.coef_[0])
            b = float(model.intercept_)
            if not np.isfinite(a) or not np.isfinite(b) or a <= 0:
                continue

            pred = model.predict(X)
            r2 = float(r2_score(y, pred)) if len(y) > 1 else np.nan
            candidates.append({
                "PIF_Combination": ";".join(combo),
                "N": int(len(sub)),
                "a": a,
                "b": b,
                "R2": r2,
            })

    if not candidates:
        raise ValueError("No valid positive-gain calibration fit could be obtained for this date/band.")

    cand = pd.DataFrame(candidates).sort_values(["R2", "N"], ascending=[False, False])
    return cand.iloc[0].to_dict()


def run(input_csv: str, output_csv: str, imagery_config: str | None = None,
        merged_config: str | None = None) -> None:
    df = pd.read_csv(input_csv)
    required = {"Date", "Band", "PIF", "DN", "TargetReflectance"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    df["Band"] = df["Band"].astype(str)
    bad_bands = sorted(set(df["Band"]) - set(BANDS))
    if bad_bands:
        raise ValueError(f"Unsupported band names: {bad_bands}. Expected one of {BANDS}.")

    rows = []
    for (date, band), group in df.groupby(["Date", "Band"], sort=True):
        best = fit_best_combination(group)
        rows.append({"Date": date, "Band": band, **best})

    result = pd.DataFrame(rows)
    out = Path(output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(out, index=False, encoding="utf-8-sig")
    print(f"Saved calibration coefficients: {out}")

    if imagery_config:
        cfg = pd.read_csv(imagery_config)
        if "Date" not in cfg.columns:
            raise ValueError("Imagery configuration must contain a Date column.")
        cfg["Date"] = cfg["Date"].astype(str)
        result["Date"] = result["Date"].astype(str)

        for band in BANDS:
            tmp = result[result["Band"] == band][["Date", "a", "b"]].rename(
                columns={"a": f"{band}_a", "b": f"{band}_b"}
            )
            cfg = cfg.merge(tmp, on="Date", how="left", suffixes=("", "_fit"))
            for col in [f"{band}_a", f"{band}_b"]:
                fit_col = f"{col}_fit"
                if fit_col in cfg.columns:
                    cfg[col] = cfg[fit_col]
                    cfg.drop(columns=[fit_col], inplace=True)

        merged_path = Path(merged_config or "imagery_config_with_calibration.csv")
        merged_path.parent.mkdir(parents=True, exist_ok=True)
        cfg.to_csv(merged_path, index=False, encoding="utf-8-sig")
        print(f"Saved imagery configuration with fitted coefficients: {merged_path}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Fit band-wise PIF relative radiometric calibration models.")
    p.add_argument("--input", required=True, help="PIF calibration sample CSV.")
    p.add_argument("--output", default="outputs/calibration/calibration_coefficients.csv")
    p.add_argument("--imagery-config", default=None, help="Optional imagery config to receive fitted a/b coefficients.")
    p.add_argument("--merged-config", default=None, help="Output path for merged imagery config.")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run(args.input, args.output, args.imagery_config, args.merged_config)
