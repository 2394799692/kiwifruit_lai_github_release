# Method workflow

The public code is organized to mirror the main methodological sequence of the paper.

1. **Relative radiometric calibration** (`code/00_fit_relative_radiometric_calibration.py`)  
   Fit band-wise empirical linear models using pseudo-invariant features: `reflectance = a * DN + b`. The paper used stable surface targets and positive-gain constraints to reduce inter-date radiometric drift.

2. **Dynamic single-plant ROI extraction** (`code/01_dynamic_roi_extraction.py`)  
   Use RTK/tree-center anchors, a 2.0 m initial exploration radius, local NDVI/NIR percentile screening, connected-component selection, and a percentile-based spatial envelope. The paper's optimal setting was `P = 90`, `Q = 70`, with radius safeguards of 0.2-2.6 m and a fallback radius of 1.5 m.

3. **Spectral and texture feature extraction** (`code/02_extract_vi_texture_features.py`)  
   Extract vegetation indices and NIR GLCM texture statistics inside the dynamic ROI.

4. **Temporal-window analysis** (`code/03_temporal_window_ablation.py`)  
   Compare phenological windows using LOOCV for temporal analysis. In the paper, the August-September window was retained for final modeling.

5. **Feature subset selection** (`code/04_feature_selection_topk.py`)  
   Rank candidate variables and evaluate Top-K subsets. The paper used a 29-feature subset for subsequent comparison.

6. **ROI strategy analysis** (`code/05_roi_strategy_ablation.py`)  
   Compare feature tables generated under alternative fixed or dynamic ROI settings. This script evaluates precomputed feature tables; it is intended as a transparent analysis helper rather than a one-command regeneration of every paper ablation.

7. **Model benchmarking** (`code/06_model_benchmark_groupcv.py`)  
   Compare GBDT, RandomForest, ExtraTrees, XGBoost (optional), KNN, SVR, PLSR, and Ridge. Tree-ID grouped cross-validation is used when tree identifiers are available.

8. **Orchard-scale mapping** (`code/07_orchard_lai_mapping.py`)  
   Train/load a GBDT model and create a LAI GeoTIFF. The mapping script is an application/reference implementation; its moving-window texture layers are computational approximations of the sample-level GLCM texture descriptors.
