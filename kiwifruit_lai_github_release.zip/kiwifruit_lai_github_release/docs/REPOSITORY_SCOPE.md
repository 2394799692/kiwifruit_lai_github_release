# Repository scope and reproducibility note

This public release is a **methodological/reference implementation** of the key processing chain described in the paper. It is designed to make the algorithmic logic, input/output formats, parameterization, and analysis workflow transparent and reusable.

It is **not a frozen archival container of every internal file used during manuscript development**. In particular:

- the full ground LAI measurement table is not bundled;
- large UAV orthomosaics are distributed through an external cloud link;
- project-specific intermediate feature tables, temporary rasters, plotting files, and local paths are intentionally omitted;
- the example CSV files are anonymized/illustrative and cannot reproduce the numerical results reported in the paper by themselves;
- exact numerical agreement can also depend on software versions, preprocessing choices, random seeds, and the complete original ground-reference data.

The repository nevertheless contains the key algorithmic components needed to understand and adapt the workflow: relative radiometric calibration, RTK-anchor-guided dynamic ROI delineation, vegetation-index and NIR texture extraction, temporal-window analysis, feature selection, ROI-strategy comparison, grouped cross-validation model benchmarking, and orchard-scale LAI mapping.

For access to additional research data or for collaboration, contact **Dr. Wenjie Li** at **17395844880@163.com**.
