# Related patent application

The core adaptive single-plant canopy ROI method associated with this repository is also the subject of a Chinese invention patent application.

## Patent information

- **Title (Chinese):** 棚架果园单株冠层 ROI 的自适应提取方法及装置
- **English description:** Adaptive extraction method and device for single-plant canopy ROI in trellis orchards
- **Application number:** 202610722903.3
- **Filing date:** May 25, 2026
- **Applicant:** Institute of Agricultural Resources and Regional Planning, Chinese Academy of Agricultural Sciences
- **Inventors:** Jianping Qian, Wenjie Li, Qian Chen, Linghuan Ouyang, Tianqi Lv, Zhen Wang, Nana Fan, Guoxun Cong, Yunlei Wang, Jiacheng Liu

## Current status

According to the official notices issued by the China National Intellectual Property Administration (CNIPA):

1. the invention patent application was **accepted on May 25, 2026**;
2. the application **passed preliminary examination on June 2, 2026**;
3. the application entered the **publication preparation procedure** after the applicant's request for early publication was approved; and
4. a **request for substantive examination** was included among the documents received at filing.

The application is therefore **pending and under the patent examination process; it has not yet been granted**.

## Official notices included in this repository

- `CN2026107229033_Acceptance_Notice_2026-05-25.pdf`
- `CN2026107229033_Preliminary_Examination_Passed_2026-06-02.pdf`

These files are provided to document the application status. Public release of the reference code is intended for scientific communication, academic reference, method comparison, and research collaboration, and does not imply transfer or waiver of any patent rights.

For research data requests, technical questions, collaboration, commercial use, or technology transfer discussions, please contact:

**Dr. Wenjie Li**  
**Email: 17395844880@163.com**
