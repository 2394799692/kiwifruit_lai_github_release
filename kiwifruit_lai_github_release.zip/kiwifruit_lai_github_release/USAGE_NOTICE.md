# Usage notice

The source code in this repository is released for scientific communication, academic reference, method comparison, and research collaboration.

Please cite the associated paper when using or adapting the method. No complete ground-reference dataset is bundled with this repository. For additional data requests, methodological questions, or collaboration, contact:

**Dr. Wenjie Li**  
Email: **17395844880@163.com**

If your institution or downstream project requires a specific software license, please contact the authors before redistribution or commercial use.

## Patent notice

The core adaptive single-plant canopy ROI method is associated with Chinese invention patent application **202610722903.3**, titled **“棚架果园单株冠层 ROI 的自适应提取方法及装置”**. The application has been accepted and has passed preliminary examination. It remains pending and has not yet been granted.

Public availability of this reference implementation does not imply transfer or waiver of patent rights. For commercial use or technology transfer discussions, please contact the authors.
